window.onload = () => {

    const objectDetailsContainer = document.getElementById('event-details');

    const eventsArray = [
        { id: 1, name: "Event 1" },
        { id: 2, name: "Event 2" },
        { id: 3, name: "Event 3" },
    ];

    function getObjectById(eventsArray, id) {
        return eventsArray.find(event => event.id === id);
    }
    
    const event = getObjectById(eventsArray, 1);

    const objectElement = document.createElement('div');
    objectElement.classList.add('eventsArray');

    const objectName = document.createElement('h2');
    objectName.textContent = event.name;
    objectElement.appendChild(objectName);

    const objectId = document.createElement('p');
    objectId.textContent = `ID: ${event.id}`;
    objectElement.appendChild(objectId);  
  
    // Append the object element to the object-details container
    objectDetailsContainer.appendChild(objectElement);
    
}