window.onload = () => {

    // $("#form_submit_btn").click(function () {
    //     $("body").css("background-color", "#a5c3fd");
    // });

    $("#form_submit_btn").click(function () {
        console.log("submit pressed.\n");
    });

    $("#top_btn_row").click(function () {
        console.log("top roq button pressed.\n");
    });

    
}

function submitAsGuest() {
    // Get the form and input elements by their IDs
    var form = document.getElementById("loginForm");
    var loginMailInput = document.getElementById("loginMail");
    var loginPassInput = document.getElementById("loginPass");

    // Set the values of the email and password fields
    loginMailInput.value = "guest";
    loginPassInput.value = "123";

    // Submit the form
    form.submit();
}